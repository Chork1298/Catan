# Hex Strategy Game — Full Project Handoff

> Paste this whole file into a fresh Claude Code (or any) session to bring it fully up to speed.
> A companion file, `war-system-design.md`, holds the detailed (parked) war-layer notes.

---

## 0. How to use this doc
This is a solo side project. The goal of the *first build* is **learning + finishing something small**,
not shipping the full vision. When in doubt, **cut toward "playable and done," not "complete."**
The big design is real and saved — but it is deliberately built in layers, smallest first.

---

## 1. The person building this
- Has written code before, but **a while ago and forgot a lot** — treat as a capable beginner
  who re-remembers fast. Explain new concepts, but don't over-baby.
- Engages deeply with design logic and will (correctly) push back when something feels off.
- Known failure mode to actively guard against: **designing more instead of building.**
  Every time the project nears "start coding," there's a pull to add one more mechanic.
  Job of the assistant: keep steering back to the build. Park new ideas in the design doc, don't chase them.
- Prefers directness but **delivered kindly** — honest pushback, not harshness.

---

## 2. The game (the vision, for context — NOT all v1)
A virtual board game blending **Catan + Risk + chess**. Procedurally generated Catan-style map.
Players expand, gather resources, build, and can optionally go to war. Key identity:
**war is an *aspect*, not the point** — you can win peacefully, but war lets you take players out
or set them back and grab their land/resources/scoring.

### Locked design decisions
- **Win by points.** Game ends at a point threshold (exact number TBD by playtesting).
- **Points come from:** holding territory (bases/buildings on tiles), biggest army, biggest navy,
  longest road, biggest cities, and winning wars (conquest transfers the loser's scoring bonuses).
  - NOTE: buying points with resources was **cut** (it enabled pure turtling).
- **Resources from dice + owned tiles**, Catan-style: roll a number → tiles with that number that
  you own produce resources → more buildings on a tile = more resources.
- **Round-based simultaneous** ("we-go"): everyone rolls → everyone collects → everyone builds/expands
  → resolve → next round. Keeps the "everyone moves at once" feel without real-time chaos.
- **Map saturation is the core engine** that prevents turtling: free expansion early (empty tiles),
  forced collision late (finite map fills up → growth must come from someone else's land).
- **War requires a road to the target** (adjacency gate) for a formal declaration.
  **Ambush** skips the formal declaration, costs more, is the surprise/no-warning option.
- Declared war resolves at the **start of the next round** (keeps simultaneous rounds deterministic).
- **Roads are the only trade routes** between players. Road upgrades can block map access (chokepoints).

### Resources (v1 set — three, each with ONE exclusive job)
- **Wood** → roads + expansion.
- **Grain** → cities + population (scoring buildings).
- **Iron** → military + upgrades.
- Rule going forward: a new resource only earns a slot if it does a job no existing resource covers.
  (Earlier four-resource list — crops/wood/iron/livestock — collapsed because they all overlapped.)

---

## 3. The war layer — PARKED
Full detail is in `war-system-design.md`. Summary of what's parked (do NOT build in v1):
two war types (declaration vs ambush), conquest transferring land + scoring bonuses, defender options
(fight / negotiate / retreat / counter-conquer), a separate 2D **battle screen**, troop training
before battle, and a 5-unit roster with a closed counter-loop
(Knight / Archer / Cavalry / Catapult / Spearman).
**Open problems still unresolved there:** ambush-with-no-distance-limit = "teleport army" (needs a leash);
battle auto-resolve vs manual control; standing army vs reactive training.
For v1, **war resolves abstractly**: army size + defender bonus + one die roll. That's it.

---

## 4. THE FIRST BUILD (this is the actual task)
**Engine: Godot, standard version (GDScript — not the .NET/C# build).**
GDScript looks like Python: readable, indentation-based, forgiving.

### v1 scope — the "first heartbeat" only
Build the smallest thing that's still recognizably this game:
1. A small grid of tiles on screen — **start at 5×5** (square grid is fine for the very first version;
   hexes come later).
2. Each tile shows a **number** and a **resource type**.
3. A **"Roll dice"** button.
4. On roll: tiles whose number matches **light up**, you **collect** their resource,
   and an on-screen **resource counter** goes up.

**That is the entire first milestone.** No war, no AI, no multiple players, no win condition, no trading.
Just: click roll → matching tiles react → resources accumulate. Once that works and feels good,
everything else bolts onto this loop.

### Explicitly NOT in v1 (parked, in priority order for later)
multiplayer/netcode · AI opponents · war of any kind · the battle screen · trading UI ·
hex maps · procedural generation · upgrades/blocking roads · win condition. All later.

---

## 5. Setup steps (do these first)
1. Download Godot from **godotengine.org** — the **standard** build (GDScript), not .NET/C#.
2. Open it → **New Project** → empty folder → default renderer → Create & Edit.
3. Confirm your **OS** (Windows / macOS / Linux) so step-by-step instructions match your screen.
4. Get a blank project open, then start with: putting a single tile on screen, then the 5×5 grid,
   then the number+resource labels, then the roll button, then the collect-and-count logic — in that order.

### Immediate next action
Open a blank Godot project and build the **5×5 grid of tiles** on screen. One step at a time.
