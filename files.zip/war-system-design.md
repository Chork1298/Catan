# War System — Design Notes (PARKED for v2/v3)

> This is the in-game war layer. It is **deliberately not part of the first build.**
> First build = the board game with **abstract war** (army size + defender bonus + one die roll).
> Everything below is preserved so nothing is lost. Revisit after the board ships.

## Core principle
- Peaceful victory is a **legitimate, complete path**. War is an *aspect*, not the point.
- War is *worth it* only when conquest pays better than building — keep checking this.
- The engine that prevents pure turtling is **map saturation**: free expansion early,
  forced collision late (finite map fills up → more land must come from someone else).

## Two kinds of war
- **Declaration** (the "proper" way): warns the defender → both sides get a prep/training step → battle.
- **Ambush**: costs more; attacker preps, **defender does NOT** → defender fights with standing force only.
  - This is what makes the two war types mechanically different. Keep them different.

## What conquest gives the winner
- Defender's **land** (→ resources), plus their **point-scoring bonuses transfer**
  (largest road, largest city, etc.). Conquest is a points *swing*, not just a land-grab.
- This also rotates the "biggest target" around the table → built-in anti-pile-on.

## Defender's options when attacked
- a) Fight back
- b) Negotiate (trade land / resources / alliance to stop it) — happens *before* battle
- c) Fight back and, if they destroy the attacker, **take the attacker's nation**
- d) Retreat to open tiles

## Cost of war (attacker)
- Resources to raise an army.
- Losing too many troops → susceptible to counter-attack or opportunistic third party.
- Army away from home → tiles left undefended.

## Elimination
- Players *can* be taken out / heavily set back (4–8, maybe 10 players).
- Watch: early elimination in a long game = bored player. Consider "set back, not out" as default.

## Anti-ganging-up (leader protection)
- **Hide exact point total and distance-to-win.** Let the *board* leak strength naturally
  (big cities/roads/armies are physically visible; the finish line is not).
- Looking-ahead ≠ being-ahead → pile-ons sometimes mis-target → not a pure "leader loses" rule.
- Intel-for-resources (espionage economy) = good idea, **v2**, not first build.

## Battle screen (FURTHEST OUT — v3 dream feature)
- Simple 2D, attacker-right / defender-left (or aerial view).
- Timed: attacker must win / defender retreats / pre-battle negotiation.
- Troops trained **before** battle; composition matters.
- Resolution should feel like a **simulation**, not rock-paper-scissors:
  units have real stats and can die to anything; some just usually beat others.
- Decision still OPEN (parked): **auto-resolve (watch)** vs **manual control (drive)**.
  Manual = effectively a second RTS game. Default to auto-resolve unless proven otherwise.

## Unit roster (closed counter-loop — keep this property for any new unit)
- **Knight** — cheap frontline tank; beats archers up close.
- **Archer** — ranged; beats slow infantry; dies to cavalry.
- **Cavalry** — fast, **expensive**; runs down ranged; **loses to spears.**
- **Catapult** — slow, expensive; AoE vs clustered units; helpless alone.
- **Spearman** — cheap, defensive; bonus vs cavalry; usable as a basic wall otherwise.
- Rule for any future unit: name what it **beats** and what it **loses to**. Both, or cut it.
- Balance via the counter-triangle first; use **cost** only for fine-tuning, not to fix dominance.

## Roads, adjacency & trade (PARKED — affects war + trade layer)
- **Declared war requires a road to the target** (adjacency gate). Geography decides who you *can* fight.
  - Good: corners safer, center exposed, real strategic depth, cheap to build (roads/tiles already exist).
  - Watch: distant players may *never* be able to fight → unreachable-corner turtle. Test, don't pre-solve.
- **Ambush is NOT road/distance-bound** — it's the surprise option, costs more, can hit anyone.
  - OPEN PROBLEM: "attack anyone from anywhere" = teleport army; can break the geography above.
    If a rich player can ambush-nuke any opponent regardless of position, distance stops mattering.
    Needs a leash (range limit? one ambush per N rounds? must still be within X tiles?). Unresolved.
- **Roads are the only way to trade** with other players (spatial trade routes). Trade follows the network.
- **Road upgrades can block** other players from accessing parts of the map (territorial control / chokepoints).
  - Watch: potentially griefy / kingmaking. Park.
- Ambush redefined: not necessarily "they don't see it coming" but "attacking WITHOUT the formal
  declaration process" — survives the road-warning rule. Keep this framing.

## Open threads to resolve later
- Train-during-rounds (standing army) vs train-at-declaration (reactive). Leaning reactive.
- Where prep resources come from; whether ambush fully removes defender prep.
- Battle auto-resolve vs manual control.
